function FirstTemplateCtrl ($scope, $rootScope, $routeParams) {

	$rootScope.headerTitle = "My Info.";
} 

function SecondTemplateCtrl ($scope, $rootScope, $routeParams) {

	$rootScope.headerTitle = "I Need a help !";
} 		

function ThirdTemplateCtrl ($scope, $rootScope, $routeParams) {

	$rootScope.headerTitle = "Help others !";
}

function FourthTemplateCtrl($scope, $rootScope, $routeParams) {

    $rootScope.headerTitle = "Nearby Places";
}

function FifthTemplateCtrl($scope, $rootScope, $routeParams) {

    $rootScope.headerTitle = "Ask Doctor ?";
}

function SixthTemplateCtrl($scope, $rootScope, $routeParams) {

    $rootScope.headerTitle = "FAQ";
}