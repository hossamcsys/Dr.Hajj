var app = angular.module('slideMenuApp', ['snap','ngRoute','ngTouch','ngResource']);

app.config(['$routeProvider', function($routeProvider) {

		$routeProvider.when('/first/:itemId?', {
			templateUrl:'templates/first-template.html',
			controller:'FirstTemplateCtrl'
		})
		.when('/second/:itemId?', {
			templateUrl:'templates/second-template.html',
			controller:'SecondTemplateCtrl'
		})
		.when('/third/:itemId?', {
			templateUrl:'templates/third-template.html',
			controller:'ThirdTemplateCtrl'
         })
         .when('/fourth/:itemId?', {
             templateUrl: 'templates/fourth-template.html',
                controller: 'FourthTemplateCtrl'
            })
            .when('/fifth/:itemId?', {
                templateUrl: 'templates/fifth-template.html',
                controller: 'FifthTemplateCtrl'
            })
            .when('/sixth/:itemId?', {
                templateUrl: 'templates/sixth-template.html',
                controller: 'SixthTemplateCtrl'
            })
		.otherwise({redirectTo: '/first'});
}]);

app.controller('MainCtrl', function($scope, $http, $location, $rootScope) {

	$scope.title = ''; //this is for the document title binding

	$scope.routingLeftMenu = function(url, id)	{
			window.location = "#/" + url + id;
	}

	$scope.init = function () {

		//Load Left Menu
		$http({method: 'GET', url: 'data/left_menu.json'}).
			success(function(data, status, headers, config) {
			$scope.items = data;
		});
	};
}); //end MainCtrl